
firebase.initializeApp(
    {
        apiKey: "AIzaSyArAosbnSgSQtAENBVgvvY0fnCrU5vk54s",
        authDomain: "fir-aut-5b4e8.firebaseapp.com",
        projectId: "fir-aut-5b4e8",
        storageBucket: "fir-aut-5b4e8.appspot.com",
        messagingSenderId: "980603892053",
        appId: "1:980603892053:web:822f7660fc633a2ce03fdc",
        measurementId: "G-7PEQHRQF21"
    });


    var db = firebase.firestore();